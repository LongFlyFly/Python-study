from scrapy import cmdline
cmdline.execute("scrapy crawl 58同城".split(" "))